sap.ui.define([],
    function() {
        'use strict';
    
        var constants = {            
            USER_INFO: 'Pick-up'
        };
    
        return constants;
    });