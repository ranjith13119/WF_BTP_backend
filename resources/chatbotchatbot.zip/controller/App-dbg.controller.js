sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("chatbot.chatbot.controller.controller.App", {
        onInit() {
        }
      });
    }
  );
  